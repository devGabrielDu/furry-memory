# Git integration for Visual Studio Code

